package ru.expensive.implement.features.draggables;

import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix4f;
import ru.expensive.api.feature.draggable.AbstractDraggable;
import ru.expensive.api.system.font.FontRenderer;
import ru.expensive.api.system.font.Fonts;
import ru.expensive.api.system.shape.ShapeProperties;
import ru.expensive.api.system.shape.implement.Image;
import ru.expensive.common.QuickImports;
import ru.expensive.common.util.other.PingUtil;
import ru.expensive.core.Expensive;
import ru.expensive.implement.features.modules.render.InterfaceModule;

import static ru.expensive.api.system.font.Fonts.Type.BOLD;

public class WatermarkDraggable extends AbstractDraggable {

    public WatermarkDraggable() {
        super("Watermark", 4, 4, 92, 16);
    }

    @Override
    public boolean visible() {
        InterfaceModule interfaceModule = (InterfaceModule) Expensive.getInstance().getModuleProvider().module("Interface");
        if (interfaceModule != null && interfaceModule.isState()) {
            return interfaceModule.getInterfaceSettings().isSelected("Watermark");
        }
        return false;
    }

    @Override
    public void drawDraggable(DrawContext context) {
        Matrix4f positionMatrix = context
                .getMatrices()
                .peek()
                .getPositionMatrix();

        setHeight(10);

        // Рисуем прямоугольник для водяного знака
        rectangle.render(ShapeProperties.create(positionMatrix, getX(), getY(), getWidth(), getHeight())
                .round(6)
                .softness(1)
                .thickness(2)
                .outlineColor(0xFF2D2E41)
                .color(0xF2141724)
                .build()
        );

        // Рисуем логотип клиента
        Image image = QuickImports.image.setMatrixStack(context.getMatrices());
        image.setTexture("textures/icon_logo.png").render(ShapeProperties.create(positionMatrix, getX() + 3, getY() + 2, 6, 6)
                .build()
        );

        FontRenderer font = Fonts.getSize(11, BOLD);
        String name = Expensive.getInstance().getClientInfoProvider().clientName();

        // Получаем пинг с помощью PingUtil и добавляем "ms"
        String ms = PingUtil.getPing() + " ms";

        String fps = mc.getCurrentFps() + " fps";

        // Иконка пинга
        image.setTexture("textures/ping.png").render(ShapeProperties.create(positionMatrix, getX() + font.getStringWidth(name) + 12.5, getY() + 0.5, 9, 9)
                .build()
        );

        // Иконка для FPS
        image.setTexture("textures/frame.png").render(ShapeProperties.create(positionMatrix, getX() + font.getStringWidth(name) + 24 + font.getStringWidth(ms), getY() + 2, 6, 6)
                .build()
        );

        // Отображаем информацию: имя клиента, пинг и FPS
        font.drawGradientString(context.getMatrices(), name, getX() + 12, getY() + 4.5, 0xFF8187FF, 0xFF4D5199);
        font.drawString(context.getMatrices(), ms, getX() + font.getStringWidth(name) + 22, getY() + 4.5, -1);
        font.drawString(context.getMatrices(), fps, getX() + font.getStringWidth(name) + 24 + font.getStringWidth(ms) + 8, getY() + 4.5, -1);

        // Устанавливаем ширину элемента, чтобы учитывать длину текста
        setWidth((int) (font.getStringWidth(name + ms + fps) + 36));
    }
}
